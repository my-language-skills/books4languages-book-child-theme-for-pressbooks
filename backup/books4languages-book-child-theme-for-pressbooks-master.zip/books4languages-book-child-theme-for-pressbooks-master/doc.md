<?php echo do_shortcode( '[shortcode_here]' ); ?>
