<?php
/**
 * Amazon Ads banner
 * @internal books4languag-20
 *
 * @since 1.x
 *
 */

if ( !is_user_logged_in() && is_singular('chapter') ) {
?>

<div class="aligncenter">
     <script type="text/javascript">
  amzn_assoc_ad_type = "banner";
	amzn_assoc_marketplace = "amazon";
	amzn_assoc_region = "US";
	amzn_assoc_placement = "assoc_banner_placement_default";
	amzn_assoc_campaigns = "amazonhomepage";
	amzn_assoc_banner_type = "rotating";
	amzn_assoc_p = "48";
	amzn_assoc_width = "728";
	amzn_assoc_height = "90";
	amzn_assoc_tracking_id = "books4languag-20";
	amzn_assoc_linkid = "2014ed5ac89f707ec0c13596ae632f06";
     </script>
     <script src="//z-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&Operation=GetScript&ID=OneJS&WS=1"></script>
</div>
<br>
<?php
}
?>
<!-- onclick="gtag('event', 'ad_click', {'event_category': 'amazon', 'event_label': 'adsbyamazon-1'});" -->

<!--
-				ADDED: Amazon.com banner
- 				 id: books4languag-20
-
-				@SINCE v
-->
<!-- <div class="aligncenter">
     <script type="text/javascript">
  amzn_assoc_ad_type = "banner";
	amzn_assoc_marketplace = "amazon";
	amzn_assoc_region = "US";
	amzn_assoc_placement = "assoc_banner_placement_default";
	amzn_assoc_campaigns = "amzn_music_bounty";
	amzn_assoc_banner_type = "category";
	amzn_assoc_p = "48";
	amzn_assoc_isresponsive = "false";
	amzn_assoc_banner_id = "01HB06M5WV0M97AGH802";
	amzn_assoc_width = "728";
	amzn_assoc_height = "90";
	amzn_assoc_tracking_id = "books4languag-20";
	amzn_assoc_linkid = "de8e1b5c66785300fda354069c9f7426";
     </script>
     <script src="//z-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&Operation=GetScript&ID=OneJS&WS=1"></script>
    </div> -->

<!-- End of added code -->
